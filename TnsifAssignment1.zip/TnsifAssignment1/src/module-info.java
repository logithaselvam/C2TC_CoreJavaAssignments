/**
 * 
 */
/**
 * 
 */
module TnsifAssignment1 {
}